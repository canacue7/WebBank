package tech.getarrays.bankmanager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankmanagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankmanagerApplication.class, args);
	}

}
